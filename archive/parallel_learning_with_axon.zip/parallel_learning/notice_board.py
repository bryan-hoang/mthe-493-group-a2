import axon

nb = axon.discovery.NoticeBoard()

nb.start()